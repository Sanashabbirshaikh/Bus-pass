<?php
namespace App\Models;
use CodeIgniter\Model;

class MAuth extends Model
{
    protected $DBGroup = "default";
    protected $table = "";
    protected $allowedFields = [];
    protected $primaryKey = "";
    protected $returnType = "array";

    protected $data = [];

    public function Auth($uname, $pass)
    {
        $this->table = "user_accounts";
        $this->primaryKey = "user_id";
        $data = array();
        $this->allowedFields = ["user_id", "profile","fname", "lname", "u_name", "p_word", "date","access_id","status"];
        $db = \Config\Database::connect();
        $builder = $db->table("user_accounts");
        $builder->select(["user_id", "profile","fname", "lname", "u_name", "p_word", "date","access_id","verify","status"]);
        //$query = $builder->get();
        $where = " `p_word`='".md5($pass)."' AND `u_name`='".$uname."'";
        $builder->where($where);
        if ($builder->countAllResults() >= 1) {
          $builder = $db->table("user_accounts");
          $builder->select(["user_id", "profile","fname", "lname", "u_name", "p_word", "date","access_id","verify","status"]);
          $where = " `p_word`='".md5($pass)."' AND `u_name`='".$uname."'";
          $builder->where($where);
          $query = $builder->get();
          foreach ($query->getResult() as $row) {
            if($row->status == 1) {
                    if ($uname == $row->u_name) {
                        if ($row->verify != 1) {
                            $data = ["status" => "Failed", "msg" => "E"];
                            return $data;
                        }
                    }
                    $data = ["status" => "Success","user_id" => $row->user_id, "u_name"=>$row->u_name,"user_profile" => $row->profile, "fname" => $row->fname, "lname" => $row->lname,"user_type" => $row->access_id];
                } else if($row->status == 2) {
                    $data = ["status"=>"Blocked","msg"=>"Your account is suspended...!"];
                }
            }
        } else {
          $builder = $db->table("user_accounts");
          $builder->select(["user_id", "profile","fname", "lname", "u_name", "p_word", "date","access_id","status"]);
          $where = " `p_word`='".$pass."' AND `u_name`='".$uname."'";
            $builder->where($where);
            $data = ["status" => "Failed","msg"=>"Account Not Found"];
        }
       // print_r($data);
        return $data;
    }

    public function Signup($fname,$lname,$email,$pass,$validate=0,$otp=0)
    {
        $data = array();
        helper('text');
        if($this->Check_Email($email)) {
            $data["status"] = "Failed";
            $data["msg"] = "1";
            return $data;
        } else {
        $this->table="user_accounts";
        $this->primaryKey="user_id";
        $this->allowedFields = ["user_id", "profile","fname", "lname", "u_name", "p_word", "date","access_id","verify","slug","status"];
            if($this->insert(["fname"=>$fname,"lname"=>$lname,"u_name"=>$email,"p_word"=>md5($pass),"date"=>date('Y-m-d H:i:s'),"access_id"=>"2","verify"=>$validate,"slug"=>$otp])) {
                $data["status"]="Success";
                $data["verify"]="Your verification Data is Sent to Your Email Please Verify";
                return $data;
            } else {
                $data["status"]="Failed";
                return $data;
            }
        }
//        echo $fname." ".$lname." ".$mobile_no." ".$email." ".$pass;
    }

    public function Check_Email($email)
    {
        $db = \Config\Database::connect();
        $builder = $db->table("user_accounts");
        $builder->select(["user_id", "user_profile","fname", "lname", "u_name", "verify","slug","status"]);
        //$query = $builder->get();
        $where = " `u_name`='".$email."'";
        $builder->where($where);
        if ($builder->countAllResults() >= 1) {
            return true;
        } else {
            return false;
        }
    }

    public function Resend($email)
    {
        helper('text');
        if($this->Check_Email($email)) {
            $db = \Config\Database::connect();
            $builder = $db->table("user_accounts");
            $builder->select(["user_id", "u_name","verify", "slug"]);
            //$query = $builder->get();
            $where = "`u_name`='".$email."'";
            $builder->where($where);
            $query = $builder->get();
            $this->table = "user_accounts";
            $this->allowedFields = ["user_id", "u_name","verify", "slug"];
            $this->primaryKey = "user_id";
            foreach ($query->getResult() as $row) {
                if($row->verify == 0) {
                    $otp = random_string('numeric',6);
                    $this->update($row->user_id,["slug"=>$otp]);
                    $data["otp"] = $otp;
                    $data["status"] = "Success";
                    // email_s($email, "Verify Your Account", "Please Verify Your Account <br> Previous Email Will Not Work", base_url('Auth/Verify/'.urlencode(base64_encode($email)).'/'.$data["otp"]),'Verify Your Account');
                    return $data;
                } else {
                    $data["otp"] = base64_encode($row->user_email_verify);
                }
            }
            $data["status"] = "Success";
            return $data;
        } else {
            return ["status"=>"Failed"];
        }
    }

    public function Verify($email,$otp)
    {
        helper('text');
        if($this->Check_Email($email)) {
            $session = session();
            $db = \Config\Database::connect();
            $builder = $db->table("user_accounts");
            $builder->select(["user_id", "u_name","verify", "slug"]);
            //$query = $builder->get();
            $where = "`u_name`='".$email."' AND `slug`='".$otp."'";
            $builder->where($where);
            $query = $builder->get();
            $this->table = "user_accounts";
            $this->allowedFields = ["user_id", "u_name","verify", "slug"];
            $this->primaryKey = "user_id";
            foreach ($query->getResult() as $row) {
                if($row->verify == 0) {
                    $this->update($row->user_id,["verify"=>"1","slug"=>""]);
                    return true;
                } else {
                    return false;
                }
            }
        } else {
            return false;
        }
    }
}
