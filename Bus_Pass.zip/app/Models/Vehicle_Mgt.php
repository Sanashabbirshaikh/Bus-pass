<?php

namespace App\Models;

use CodeIgniter\Model;

class Vehicle_Mgt extends Model
{
    protected $DBGroup = "default";
    protected $table = "";
    protected $allowedFields = [];
    protected $primaryKey = "";
    protected $returnType = "array";
    protected $data = [];

    public function Create_Vehicle($vehicle_no,$vehicle_name,$vehicle_route)
    {
        $session = session();
        $this->table = "vehicles";
        $this->allowedFields = ["vehicle_no", "vehicle_name", "vehicle_route"];
        $this->primaryKey = "vehicle_id";
        if($this->insert(["vehicle_no"=>$vehicle_no, "vehicle_name"=>$vehicle_name,"vehicle_route"=>$vehicle_route])) {
            return true;
        } else {
            return false;
        }
    }

    public function Get_All_Vehicles($vehicle_id=0) {
        $db = \Config\Database::connect();
        $builder = $db->table("vehicles");
        $builder->select(["vehicle_id", "vehicle_no", "vehicle_name","vehicle_route"]);
        //$query = $builder->get();
        if($vehicle_id != 0) {
            $builder->where("`vehicle_id`='".$vehicle_id."'");
        }
        $query = $builder->get();
        $data = [];
        $i = 0;
        foreach ($query->getResult() as $row) {
            $data[$i]["vehicle_no"] = $row->vehicle_no;
            $data[$i]["vehicle_name"] = $row->vehicle_name;
            $data[$i]["vehicle_id"] = $row->vehicle_id;
            $data[$i]["vehicle_route"] = $row->vehicle_route;
            $i++;
        }
        return $data;
    }

    public function Add_Student($student_name,$class,$branch,$email="",$mobile_no="") {
        $session = session();
        $this->table = "students";
        $this->allowedFields = ["student_id", "name", "class", "branch", "email", "mobile_no"];
        $this->primaryKey = "student_id";
        if($this->insert(["name"=>$student_name, "class"=>$class,"branch"=>$branch,"email"=>$email,"mobile_no"=>$mobile_no])) {
            return true;
        } else {
            return false;
        }
    }

    public function Get_All_Students($student_id=0) {
        $db = \Config\Database::connect();
        $builder = $db->table("students");
        $builder->select(["student_id", "name", "class", "branch", "email", "mobile_no"]);
        //$query = $builder->get();
        if($student_id != 0) {
            $builder->where("`student_id`='".$student_id."'");
        }
        $query = $builder->get();
        $data = [];
        $i = 0;
        foreach ($query->getResult() as $row) {
            $data[$i]["student_id"] = $row->student_id ;
            $data[$i]["name"] = $row->name;
            $data[$i]["class"] = $row->class;
            $data[$i]["branch"] = $row->branch;
            $data[$i]["email"] = $row->email;
            $data[$i]["mobile_no"] = $row->mobile_no;
            $i++;
        }
        return $data;
    }

    public function create_pass($student_id,$start_date,$end_date,$price) {
        $session = session();
        $this->table = "passes";
        $this->allowedFields = ["student_id","start_date","end_date","price"];
        $this->primaryKey = "pass_id";
        if($this->insert(["student_id"=>$student_id,"start_date"=>$start_date,"end_date"=>$end_date,"price"=>$price])) {
            return true;
        } else {
            return false;
        }
    }

    public function view_pass($pass_id=0) {
        $db = \Config\Database::connect();
        $builder = $db->table("passes");
        $builder->select(["pass_id","student_id", "start_date", "end_date", "price"]);
        //$query = $builder->get();
        if($pass_id != 0) {
            $builder->where(" `pass_id`='".$pass_id."' ORDER BY pass_id DESC");
        } else {
//            $builder->where(" ORDER BY `pass_id` DESC");
        }
        $query = $builder->get();
        $data = [];
        $i = 0;
        foreach ($query->getResult() as $row) {
            $data[$i]["pass_id"] = $row->pass_id ;

            $temp = $this->Get_All_Students($row->student_id);

            $data[$i]["name"] = $temp[0]["name"];
            $data[$i]["start_date"] = $row->start_date;
            $data[$i]["end_date"] = $row->end_date;
            $data[$i]["price"] = $row->price;
            $i++;
        }
        return $data;
    }

}