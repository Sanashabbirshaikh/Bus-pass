<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font Awesome -->
    <link
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
            rel="stylesheet"
    />
    <!-- Google Fonts -->
    <link
            href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
            rel="stylesheet"
    />
    <!-- MDB -->
    <link
            href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css"
            rel="stylesheet"
    />
    <style>
        .divider:after,
        .divider:before {
            content: "";
            flex: 1;
            height: 1px;
            background: #eee;
        }

        .h-custom {
            height: calc(100% - 73px);
        }

        @media (max-width: 450px) {
            .h-custom {
                height: 100%;
            }
        }
    </style>
</head>
<!-- END HEAD -->
<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white dark-color logo-dark">
<!-- Navbar -->
<?php include ('nav.php'); ?>
<!-- Navbar -->
<div class="page-wrapper">
    <!-- start page container -->
    <div class="page-container">
        <section class="pb-4">
            <div class="bg-white border rounded-5">
                <section class="w-100 p-4 d-flex justify-content-center pb-4">
                    <form class="txt-center" method="post" action="<?= base_url("/Home/Create_Student") ?>" style="width: 26rem;" >

                        <h4> Create Student </h4>
                        <div class="form-outline mb-4">
                            <input required type="text" name="name" class="form-control">
                            <label class="form-label" for="form3Example3" style="margin-left: 0px;">Student Name.</label>
                            <div class="form-notch">
                                <div class="form-notch-leading" style="width: 9px;"></div>
                                <div class="form-notch-middle" style="width: 88.8px;"></div>
                                <div class="form-notch-trailing"></div>
                            </div>
                        </div>

                        <select name="class" required class="browser-default custom-select form-control mb-4">
                            <option selected>Select Class</option>
                            <option value="1">FE</option>
                            <option value="2">SE</option>
                            <option value="3">TE</option>
                            <option value="4">BE</option>
                        </select>

                        <select name="branch" required class="browser-default custom-select form-control mb-4">
                            <option selected>Select Branch</option>
                            <option value="1">CSE</option>
                        </select>

                        <div class="form-outline mb-4">
                            <input required type="email" name="email" class="form-control">
                            <label class="form-label" for="form3Example3" style="margin-left: 0px;">Email</label>
                            <div class="form-notch">
                                <div class="form-notch-leading" style="width: 9px;"></div>
                                <div class="form-notch-middle" style="width: 88.8px;"></div>
                                <div class="form-notch-trailing"></div>
                            </div>
                        </div>

                        <div class="form-outline mb-4">
                            <input required type="number" name="mobile_no" class="form-control">
                            <label class="form-label" for="form3Example3" style="margin-left: 0px;">Mobile No.</label>
                            <div class="form-notch">
                                <div class="form-notch-leading" style="width: 9px;"></div>
                                <div class="form-notch-middle" style="width: 88.8px;"></div>
                                <div class="form-notch-trailing"></div>
                            </div>
                        </div>

                        <!-- Submit button -->
                        <button type="submit" name="Create_Student" class="btn btn-primary btn-block mb-4">Create Student</button>
                    </form>
                </section>
            </div>
        </section>
    </div>
    <?php include ('footer.php'); ?>


    <!-- end page container -->
</div>
<script
        type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.js"
></script>
<!-- end js include path -->
</body>

</html>
