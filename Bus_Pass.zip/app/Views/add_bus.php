<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font Awesome -->
    <link
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
            rel="stylesheet"
    />
    <!-- Google Fonts -->
    <link
            href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
            rel="stylesheet"
    />
    <!-- MDB -->
    <link
            href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css"
            rel="stylesheet"
    />
    <style>
        .divider:after,
        .divider:before {
            content: "";
            flex: 1;
            height: 1px;
            background: #eee;
        }

        .h-custom {
            height: calc(100% - 73px);
        }

        @media (max-width: 450px) {
            .h-custom {
                height: 100%;
            }
        }
    </style>
</head>
<!-- END HEAD -->
<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white dark-color logo-dark">
<!-- Navbar -->
<?php include ('nav.php'); ?>
<!-- Navbar -->
<div class="page-wrapper">
    <!-- start page container -->
    <div class="page-container">
        <section class="pb-4">
            <div class="bg-white border rounded-5">
                <section class="w-100 p-4 d-flex justify-content-center pb-4">
                    <form class="txt-center" method="post" action="<?= base_url("/Home/Create_Vehicle") ?>" style="width: 26rem;" >

                        <h4> Create Vehicle </h4>

                        <!-- Email input -->
                        <div class="form-outline mb-4">
                            <input type="text" name="vehicle_no" class="form-control">
                            <label class="form-label" for="form3Example3" style="margin-left: 0px;">Vehicle No.</label>
                            <div class="form-notch">
                                <div class="form-notch-leading" style="width: 9px;"></div>
                                <div class="form-notch-middle" style="width: 88.8px;"></div>
                                <div class="form-notch-trailing"></div>
                            </div>
                        </div>

                        <div class="form-outline mb-4">
                            <input type="text" name="vehicle_name" class="form-control">
                            <label class="form-label" for="form3Example3" style="margin-left: 0px;">Vehicle Name.</label>
                            <div class="form-notch">
                                <div class="form-notch-leading" style="width: 9px;"></div>
                                <div class="form-notch-middle" style="width: 88.8px;"></div>
                                <div class="form-notch-trailing"></div>
                            </div>
                        </div>

                        <div class="form-outline mb-4">
                            <textarea name="vehicle_route" class="form-control" id="textAreaExample" rows="4"></textarea>
                            <label class="form-label" for="textAreaExample">Bus Route</label>
                        </div>

                        <!-- Submit button -->
                        <button type="submit" class="btn btn-primary btn-block mb-4">Sign up</button>
                    </form>
                </section>
            </div>
        </section>
    </div>
    <?php include ('footer.php'); ?>


    <!-- end page container -->
</div>
<script
        type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.js"
></script>
<!-- end js include path -->
</body>

</html>
