<?php


namespace App\Controllers;
use App\Models\MAuth;
use App\Models\MUser;

class Auth extends BaseController
{
    public function Check_Status() {
        $session = session();
      		if(isset($_SESSION["user_id"]) && isset($_SESSION["user_type"])) {
      			return true;
      		} else {
      			return false;
          }
    }

    public function Login() {
        $session = session();
        if($this->Check_Status()) {
            return redirect()->to(base_url().'/Home');
        } else {
            if(isset($_POST["Authenticate"])) {
                $md_auth = new MAuth();
                $data = $md_auth->Auth($_POST["userid"],$_POST["password"]);
                if($data["status"]=="Success") {
                    $session->set($data);
                    $session->remove('status');
                    return redirect()->to(base_url()."/Home");
                } else {
                    if($data["status"] == "Failed")
                    {
                        if(isset($data["msg"]) && $data["msg"] == "E") {
                            return redirect()->to(base_url()."/Auth/Resend");
                        } else {
                            if(isset($data["msg"])) {
                              return view('login',["status"=>"E","msg"=>$data["msg"]]);
                            } else {
                              return view('login',["status"=>"E","msg"=>"Wrong username or password"]);
                            }
                        }
                    } else {
                        if(isset($data["msg"])) {
                            return view('login',["status"=>"E","msg"=>$data["msg"]]);
                        } else {
                            return view('login',["status"=>"E","msg"=>"Wrong username or password"]);
                        }
                    }
                }
            } else {
                $data["alert"] = $session->getFlashdata('alert');
                return view('login',$data);
            }
        }
    }

    public function Add_User() {
        helper('text');
        $email = \Config\Services::email();
        $session = session();
        if(!$this->Check_Status()) {
            return redirect()-> to(base_url('Home'));
        } else {
            if(isset($_POST["Register"]) && $_SESSION["user_type"]==1) {
                if($_POST["pass"]==$_POST["con_pass"]) {
                    $md_auth = new MAuth();
                    $mail = $_POST["email"];
                    $data = $md_auth->Signup($_POST["fname"],$_POST["lname"],$mail,$_POST["pass"],1);
                    if($data["status"]=="Success") {
                       
                       $session->setFlashdata('alert', ["color"=>"green","data"=>"User Created Successfully"]);
                       return redirect()->to(base_url('Home'));
                       // return redirect()->to(base_url("Home"));
                    } else if($data["status"] == "Failed") {
                        return view('login',["status"=>"Failed","msg"=>'Email id is already Exist please Login....']);
                    } else {
                        // var_dump($data);
                                                // return redirect()->to(base_url()."/Signup");
                    }
                } else {
                    // return view('signup',["type"=>"2","error"=>"Password Not Match","code"=>"4"]);
                }
            } else {
                // return redirect()->to(base_url("Home"));
                return redirect()->to(base_url()."/Signup");
            }
        }
    }
    
    public function Signup() {
        helper('text');
        $email = \Config\Services::email();
        $session = session();
        $md_auth = new MAuth();
        if($this->Check_Status()) {
            // var_dump($this->Check_Status());
            return redirect()-> to(base_url('Home'));
        } else {
            if(isset($_POST["Register"])) {
                $email = $_POST["email"];
                if($md_auth->Check_Email($email)) {
                    $session->setFlashdata('alert', ["color"=>"red","data"=>"Email Alredy Exist"]);
                    return redirect()->to(base_url("Signup"));
                } else if($_POST["pass"]==$_POST["con_pass"]) {
                    $mail = $_POST["email"];
                    $otp_email = random_string('alnum',8);
                    $data = $md_auth->Signup($_POST["fname"],$_POST["lname"],$mail,$_POST["pass"],0,$otp_email);
                    if($data["status"]=="Success") {
                        
                        $session->setFlashdata('alert', ["color"=>"success","data"=>"User Created Successfully Please Verify Your Email Address"]);
                        email_s($email, "Verify Your Account", "Please Verify Your Account", base_url('Auth/Verify/'.urlencode(base64_encode($mail)).'/'.$otp_email),'Verify Your Account');
                        // $session->setFlashdata('alert', ["color"=>"green","data"=>"User Created Successfully"]);
                        return redirect()->to(base_url('Home'));
                    } else if($data["status"] == "Failed") {
                        return view('login',["alert"=>["color"=>"danger","data"=>'Email id is already Exist please Login....']]);
                    } else {
                        return redirect()->to(base_url()."/Signup");
                    }
                } else {
                    return view('signup',["alert"=>["color"=>"danger","data"=>'Password Not Match....']]);
                }
            } else {
                // return redirect()->to(base_url("Home"));
                return redirect()->to(base_url()."/Signup");
            }
        }
    }

    public function Forgot() {
        if($this->Check_Status()) {
            return redirect()->to('Home');
        } else {
            if(isset($_POST["Authenticate"])) {
                // print_r($_POST);
            } else {
                return view('forgot');
            }
        }
    }

    public function Verify($email,$otp)
    {
        if(isset($email) && isset($otp)) {
            $auth = new MAuth();
            $session = session();
            if($auth->Verify(urldecode(base64_decode($email)),$otp)) {
                $session->setFlashdata('alert', ["color"=>"success","data"=>"Your Account Verified Successfully <br> Please Login"]);
                return redirect()->to(base_url()."/Login");
            } else {
                $session->setFlashdata('alert', ["color"=>"danger","data"=>"Something Went Wrong <br> Please Contact Administrator"]);
                return redirect()->to(base_url()."/Auth/Resend");
            }
        } else {
            return redirect()->to(base_url()."/Auth/Resend");
        }
    }

    public function Get_User() {
       if(isset($_SESSION["ad_admin_aid"])){

       } else {
           return redirect()->to(base_url()."/Auth/Verify/".$_SESSION["user_uid"]."/Access?code=5050");
       }
    }

    public function User_Operations() {
        if(isset($_SESSION["ad_admin_aid"])){

        } else {
            return redirect()->to(base_url()."/Auth/Verify/".$_SESSION["user_uid"]."/Access?code=5050");
       }
    }

    public function Logout()
    {
        $session = session();
        $session->remove($_SESSION);
        unset(
            $_SESSION["user_id"], $_SESSION["fname"], $_SESSION["lname"], $_SESSION["img"], $_SESSION["access"]
        );
        $session->destroy();
        return redirect()->to("Login");
    }

    public function Resend() {
        $session = session();
        $email = \Config\Services::email();
        if(isset($_SESSION["user_id"])){
            return redirect()->to(base_url()."/Home");
        } else if(isset($_POST["send_mail"])) {
            $mail = $_POST["email"];
            $auth = new MAuth();
            $data = $auth->Resend($mail);
            if(isset($data["status"]) && $data["status"]=="Success") {
                // $email->setFrom('admin@coreprograming.com', 'Admin Core Programming');
                // $email->setTo($_POST["email"]);

                // $email->setSubject('Verification Email');
                // $email->setMessage('<a href="'.base_url().'/Auth/Verify/'.base64_encode($mail).'/'.$data["otp"].'">Verify Your Email here</a>');
    
                if(email_s($mail, "Verify Your Account", "Please Verify Your Account <br> Previous Email Will Not Work", base_url('Auth/Verify/'.urlencode(base64_encode($mail)).'/'.$data["otp"]),'Verify Your Account')) {
                    // return view('login',["alert"=>["color"=>"success","data"=>"We have Send The verification email To Your Mail"]]);
                    $session->setFlashdata('alert', ["color"=>"success","data"=>"We have Send The verification email To Your Mail"]);
                    return redirect()->to(base_url());
                } else {
                    return redirect()->to(base_url().'/Auth/Resend');
                }
            } else {
               return view('resend_mail',[alert=>["color"=>"danger","data"=>"Email Not Found"]]);
            }
        } else {
            return view('resend_mail');
        }
    }

}

?>
