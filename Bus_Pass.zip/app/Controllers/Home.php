<?php namespace App\Controllers;
use App\Models\MForms;
use App\Models\MUser;
use App\Models\MWallet;
use App\Models\Vehicle_Mgt;

class Home extends BaseController {

	public function Check() {
		$session = session();
		if(isset($_SESSION["user_id"]) && isset($_SESSION["user_type"])) {
			return true;
		} else {
			return false;
		}
	}

	public function index() {
		$session = session();
        if($this->Check()) {
            $data["alert"] = $session->getFlashdata('alert');
            return view('add_bus');
        } else {
            return redirect()->to(base_url("Login"));
        }
	}

    public function Create_Vehicle() {
        if($this->Check()) {
            $vehicle_no = $_POST["vehicle_no"];
            $vehicle_name = $_POST["vehicle_name"];
            $vehicle_route = $_POST["vehicle_route"];
            $vehicle = new Vehicle_Mgt();

            if($vehicle->Create_Vehicle($vehicle_no,$vehicle_name,$vehicle_route)) {
                return redirect()->to(base_url("Home/List_Vehicle"));
            } else {
                return redirect()->to(base_url("Home/Create_Vehicle"));
            }
        } else {
            return redirect()->to(base_url("/Login"));
        }
    }

    public function Create_Student() {
        if($this->Check()) {
            if(isset($_POST["Create_Student"])) {
                $student = new Vehicle_Mgt();
                $name = $_POST["name"];
                $class = $_POST["class"];
                $branch = $_POST["branch"];
                $email = "";
                $mobile_no = "";
                if(isset($_POST["email"])) {
                    $email = $_POST["email"];
                }
                if(isset($_POST["mobile_no"])) {
                    $mobile_no = $_POST["mobile_no"];
                }
                if($student->Add_Student($name,$class,$branch,$email,$mobile_no)) {
                    return redirect()->to(base_url("Home/List_Student"));
                } else {
                    return redirect()->to(base_url("Home/Create_Student"));
                }
            } else {
                return view('add_student');
            }
        } else {
            return redirect()->to(base_url("/Login"));
        }
    }

    public function List_Vehicle() {
        if($this->Check()) {
            $vehicle = new Vehicle_Mgt();
            $vehicles = $vehicle->Get_All_Vehicles();
            return view('view_all_bus', ["vehicles" => $vehicles]);
        } else {
            return redirect()->to(base_url("/Login"));
        }
    }

    public function List_Student() {
        if($this->Check()) {
            $vehicle = new Vehicle_Mgt();
            $students = $vehicle->Get_All_Students();
            return view('view_all_students', ["students" => $students]);
        } else {
            return redirect()->to(base_url("/Login"));
        }
    }

    public function Create_Pass() {
        if($this->Check()) {
            $vehicle = new Vehicle_Mgt();
            if(isset($_POST["Create_Pass"])) {
                $student_id = $_POST["student_id"];
                $start_date = $_POST["start_date"];
                $end_date = $_POST["end_date"];
                $price = $_POST["price"];
                if($vehicle->create_pass($student_id,$start_date,$end_date,$price)) {
                    return redirect()->to(base_url("/Home/List_Pass"));
                } else {
                    return redirect()->to(base_url("/Home/Create_Pass"));
                }
            } else {
                $students = $vehicle->Get_All_Students();
//                var_dump($students);
                return view('add_pass',["students"=>$students]);
            }
        } else {
            return redirect()->to(base_url("/Login"));
        }
    }

    public function List_Pass() {
        if($this->Check()) {
            $vehicle = new Vehicle_Mgt();
            $passes = $vehicle->view_pass();
            return view('view_all_pass', ["passes" => $passes]);
        } else {
            return redirect()->to(base_url("/Login"));
        }
    }
}
